/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;


import java.util.Comparator;
import java.util.List;


public class Ordenacao {
    
    
    // Comparadores prontos
    public static final Comparator<Produto> POR_ID = Comparator.comparingInt(Produto::getId);
    public static final Comparator<Produto> POR_NOME = (p1, p2) -> p1.getNome().compareToIgnoreCase(p2.getNome());
    public static final Comparator<Produto> POR_PRECO = Comparator.comparingDouble(Produto::getPreco);

    
    public static boolean bolha(List<Produto> lista, Comparator<Produto> comp, long timeoutNs) {
        long inicio = System.nanoTime();
        boolean houveTroca;
        int n = lista.size();

        do {
            if (timeoutNs > 0 && (System.nanoTime() - inicio) > timeoutNs) {
                return false; // Interrompe se passar de 2 minutos
            }

            houveTroca = false;
            for (int i = 0; i < n - 1; i++) {
                if (comp.compare(lista.get(i), lista.get(i + 1)) > 0) {
                    houveTroca = true;
                    Produto tmp = lista.get(i);
                    lista.set(i, lista.get(i + 1));
                    lista.set(i + 1, tmp);
                }
            }
            n--; 
        } while (houveTroca);

        return true;
    }

   
    public static void quickSort(List<Produto> lista, Comparator<Produto> comp) {
        if (lista == null || lista.size() <= 1) return;
        quickSortRecursivo(lista, 0, lista.size() - 1, comp);
    }

    private static void quickSortRecursivo(List<Produto> lista, int inicio, int fim, Comparator<Produto> comp) {
        if (inicio < fim) {
            int indicePivo = particionar(lista, inicio, fim, comp);
            quickSortRecursivo(lista, inicio, indicePivo - 1, comp);
            quickSortRecursivo(lista, indicePivo + 1, fim, comp);
        }
    }

    private static int particionar(List<Produto> lista, int inicio, int fim, Comparator<Produto> comp) {
        
        int meio = inicio + (fim - inicio) / 2;
        trocar(lista, meio, fim);

        Produto pivo = lista.get(fim);
        int i = inicio - 1;

        for (int j = inicio; j < fim; j++) {
            if (comp.compare(lista.get(j), pivo) <= 0) {
                i++;
                trocar(lista, i, j);
            }
        }
        trocar(lista, i + 1, fim);
        return i + 1;
    }

    private static void trocar(List<Produto> lista, int i, int j) {
        Produto temp = lista.get(i);
        lista.set(i, lista.get(j));
        lista.set(j, temp);
    }
}


