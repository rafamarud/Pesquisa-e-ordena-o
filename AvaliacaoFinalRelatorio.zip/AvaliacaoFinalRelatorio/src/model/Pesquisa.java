/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.List;

/**
 *
 * @author laboratorio
 */
public class Pesquisa {
    public static Produto buscaLinearPorId(List<Produto> lista, int id) {
        for (Produto p : lista) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null;
    }

    // Busca Binária O(log n) - exige lista ordenada por ID
    public static Produto buscaBinariaPorId(List<Produto> listaOrdenadaPorId, int id) {
        int esquerda = 0;
        int direita = listaOrdenadaPorId.size() - 1;

        while (esquerda <= direita) {
            int meio = esquerda + (direita - esquerda) / 2;
            int idMeio = listaOrdenadaPorId.get(meio).getId();

            if (idMeio == id) {
                return listaOrdenadaPorId.get(meio);
            } else if (idMeio < id) {
                esquerda = meio + 1;
            } else {
                direita = meio - 1;
            }
        }
        return null;
    }

}
