package util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import model.Produto;

public class Util {
    public static boolean carregarArquivosEmLista(String nomeArquivo, ArrayList<Produto> listaDestino) {
        if (listaDestino == null) {
            return false;
        }
        try (BufferedReader leitor = new BufferedReader(new FileReader(nomeArquivo, StandardCharsets.UTF_8))) {
            // Pula a primeira linha (cabeçalho do arquivo)
            leitor.readLine();
            
            String linha;
            while ((linha = leitor.readLine()) != null) {
                // Ignorar linhas vazias
                if (linha.trim().isEmpty()) continue;

                String[] dados = linha.split(";");
                if (dados.length < 5) continue; // Evita IndexOutOfBoundsException

                int id = Integer.parseInt(dados[0].trim());
                String nome = dados[1].trim();
                String categoria = dados[2].trim();
                
                // Substitui vírgula por ponto caso o arquivo use formato brasileiro (ex: 19,90)
                double preco = Double.parseDouble(dados[3].trim().replace(",", "."));
                int estoque = Integer.parseInt(dados[4].trim());

                Produto produto = new Produto(id, nome, categoria, preco, estoque);
                if (!listaDestino.contains(produto)) {
                    listaDestino.add(produto);
                }
            }
            for (Produto item : listaDestino) {
                
            }
            return true; // Sucesso ao carregar
        } catch (IOException | NumberFormatException e) {
            System.err.println("Ocorreu algum erro: " + e.getMessage());
            return false; // Falha na leitura ou conversão
        }
    }
}
