/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import model.Ordenacao;
import model.Produto;

public class GerarRelatorio {
    public static Produto buscaLinearPorId(List<Produto> lista, int id) {
        for (Produto p : lista) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null;
    }

    // Busca Binária O(log n) - exige lista ordenada por ID
    public static Produto buscaBinariaPorId(List<Produto> listaOrdenadaPorId, int id) {
        int esquerda = 0;
        int direita = listaOrdenadaPorId.size() - 1;

        while (esquerda <= direita) {
            int meio = esquerda + (direita - esquerda) / 2;
            int idMeio = listaOrdenadaPorId.get(meio).getId();

            if (idMeio == id) {
                return listaOrdenadaPorId.get(meio);
            } else if (idMeio < id) {
                esquerda = meio + 1;
            } else {
                direita = meio - 1;
            }
        }
        return null;
    }

    /**
     * Executa o benchmark nos 3 arquivos, salva 'relatorio.txt' e retorna
     * os dados formatados para preencher a JTable (tbl_Tempos).
     */
    public static Object[][] gerarRelatorioCompleto() throws IOException {
        String[] arquivos = {
            "src/util/produtos_1000.txt",
            "src/util/produtos_10000.txt",
            "src/util/produtos_50000.txt"
        };

        String[] ordSimples = new String[3];
        String[] ordEficiente = new String[3];
        String[] buscaLinear = new String[3];
        String[] buscaBinaria = new String[3];
        String[] buscaHash = new String[3];
        String[] constrHash = new String[3];

        long doisMinutosNs = 120_000_000_000L;
        int repeticoesBusca = 1000;

        for (int i = 0; i < arquivos.length; i++) {
            ArrayList<Produto> base = new ArrayList<>();
            boolean ok = Util.carregarArquivosEmLista(arquivos[i], base);
            if (!ok || base.isEmpty()) {
                throw new IOException("Não foi possível ler o arquivo: " + arquivos[i]);
            }

            // Pega o ID do último produto da lista para testar a busca
            int idAlvo = base.get(base.size() - 1).getId();

            // 1. Construção do HashMap<Integer, Produto>
            HashMap<Integer, Produto> mapaPorId = new HashMap<>();
            long tHashIni = System.nanoTime();
            for (Produto p : base) {
                mapaPorId.put(p.getId(), p);
            }
            long tHashFim = System.nanoTime();
            constrHash[i] = String.format(Locale.US, "%.3f ms", (tHashFim - tHashIni) / 1e6);

            // 2. Ordenação Simples (Bubble Sort por preço)
            ArrayList<Produto> copiaSimples = new ArrayList<>(base);
            long tSimplesIni = System.nanoTime();
            boolean concluiu = Ordenacao.bolha(copiaSimples, Ordenacao.POR_PRECO, doisMinutosNs);
            if (concluiu) {
                ordSimples[i] = String.format(Locale.US, "%.3f ms", (System.nanoTime() - tSimplesIni) / 1e6);
            } else {
                ordSimples[i] = "não concluído (> 2 min)";
            }

            // 3. Ordenação Eficiente (Quick Sort por preço)
            ArrayList<Produto> copiaEficiente = new ArrayList<>(base);
            long tEficIni = System.nanoTime();
            Ordenacao.quickSort(copiaEficiente, Ordenacao.POR_PRECO);
            ordEficiente[i] = String.format(Locale.US, "%.3f ms", (System.nanoTime() - tEficIni) / 1e6);

            // 4. Busca Linear por ID (média de 1.000 execuções)
            long tLinIni = System.nanoTime();
            for (int r = 0; r < repeticoesBusca; r++) {
                buscaLinearPorId(base, idAlvo);
            }
            buscaLinear[i] = String.format(Locale.US, "%.2f ns", (double) (System.nanoTime() - tLinIni) / repeticoesBusca);

            // 5. Busca Binária por ID (ordena por ID antes, mede média de 1.000 execuções)
            ArrayList<Produto> ordenadaPorId = new ArrayList<>(base);
            Ordenacao.quickSort(ordenadaPorId, Ordenacao.POR_ID);
            long tBinIni = System.nanoTime();
            for (int r = 0; r < repeticoesBusca; r++) {
                buscaBinariaPorId(ordenadaPorId, idAlvo);
            }
            buscaBinaria[i] = String.format(Locale.US, "%.2f ns", (double) (System.nanoTime() - tBinIni) / repeticoesBusca);

            // 6. Busca por HashMap por ID (média de 1.000 execuções)
            long tHashBuscaIni = System.nanoTime();
            for (int r = 0; r < repeticoesBusca; r++) {
                mapaPorId.get(idAlvo);
            }
            buscaHash[i] = String.format(Locale.US, "%.2f ns", (double) (System.nanoTime() - tHashBuscaIni) / repeticoesBusca);
        }

        // Monta o texto do arquivo relatorio.txt
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-35s | %-18s | %-18s | %-22s%n", "Operação", "1.000", "10.000", "50.000"));
        sb.append("-------------------------------------------------------------------------------------------------\n");
        sb.append(String.format("%-35s | %-18s | %-18s | %-22s%n", "Ordenação simples (por preço)", ordSimples[0], ordSimples[1], ordSimples[2]));
        sb.append(String.format("%-35s | %-18s | %-18s | %-22s%n", "Ordenação eficiente (por preço)", ordEficiente[0], ordEficiente[1], ordEficiente[2]));
        sb.append(String.format("%-35s | %-18s | %-18s | %-22s%n", "Busca linear por id (média)", buscaLinear[0], buscaLinear[1], buscaLinear[2]));
        sb.append(String.format("%-35s | %-18s | %-18s | %-22s%n", "Busca binária por id (média)", buscaBinaria[0], buscaBinaria[1], buscaBinaria[2]));
        sb.append(String.format("%-35s | %-18s | %-18s | %-22s%n", "Busca por HashMap (média)", buscaHash[0], buscaHash[1], buscaHash[2]));
        sb.append(String.format("%-35s | %-18s | %-18s | %-22s%n", "Construção do HashMap", constrHash[0], constrHash[1], constrHash[2]));
        sb.append("-------------------------------------------------------------------------------------------------\n\n");
        sb.append("Conclusão:\n");
        sb.append("A busca por HashMap foi a mais rápida porque calcula o hash da chave e acessa diretamente a posição na memória em tempo constante O(1), sem percorrer a lista como a busca linear O(n) nem dividir intervalos como a binária O(log n). Vale a pena pagar o custo O(n) de construir o HashMap quando o programa realiza várias buscas repetidas sobre os dados, diluindo o tempo inicial de indexação.\n");

        try (BufferedWriter bw = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream("relatorio.txt"), StandardCharsets.UTF_8))) {
            bw.write(sb.toString());
        }

        // Retorna as linhas prontas para atualizar a tbl_Tempos no JFrame
        return new Object[][] {
            {"Ordenação simples (por preço)", ordSimples[0], ordSimples[1], ordSimples[2]},
            {"Ordenação eficiente (por preço)", ordEficiente[0], ordEficiente[1], ordEficiente[2]},
            {"Busca linear por id (média)", buscaLinear[0], buscaLinear[1], buscaLinear[2]},
            {"Busca binária por id (média)", buscaBinaria[0], buscaBinaria[1], buscaBinaria[2]},
            {"Busca por HashMap (média)", buscaHash[0], buscaHash[1], buscaHash[2]},
            {"Construção do HashMap", constrHash[0], constrHash[1], constrHash[2]}
        };
    }
}

