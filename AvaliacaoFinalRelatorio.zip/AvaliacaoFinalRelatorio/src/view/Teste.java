/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.util.ArrayList;
import model.Produto;
import util.Util;

public class Teste {
    public static void main(String[] args) {
        ArrayList<Produto> listaDestino = new ArrayList<>();
        
        boolean carregou1 = Util.carregarArquivosEmLista("src/util/produtos_1000.txt", listaDestino);
        boolean carregou2 = Util.carregarArquivosEmLista("src/util/produtos_10000.txt", listaDestino);
        boolean carregou3 = Util.carregarArquivosEmLista("src/util/produtos_50000.txt", listaDestino);
    }
}