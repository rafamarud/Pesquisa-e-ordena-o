/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;


import java.util.List;


public class Ordenacao {
    
    
    public static void bolha(List<Integer> lista) {
    boolean houveTroca;
    int tmp;
    int qtdComparacoes = 0, qtdTrocas = 0;

    do {
        houveTroca = false;
        for (int i = 0; i < lista.size() - 1; i++) {
            qtdComparacoes++;
            if (lista.get(i) > lista.get(i + 1)) {
                qtdTrocas++;
                houveTroca = true;
                
                tmp = lista.get(i);
                lista.set(i, lista.get(i + 1));
                lista.set(i + 1, tmp);
            }
        }
    } while (houveTroca);
}
    
    public static void quickSort(int[] array, int inicio, int fim) {
        if (inicio < fim) {
            // Encontra o índice onde o pivô ficou posicionado corretamente
            int indicePivo = particionar(array, inicio, fim);

            // Ordena recursivamente os elementos antes e depois do pivô
            quickSort(array, inicio, indicePivo - 1);
            quickSort(array, indicePivo + 1, fim);
        }
    }

    // Rearranja o array colocando menores à esquerda e maiores à direita do pivô
    private static int particionar(int[] array, int inicio, int fim) {
        int pivo = array[fim]; // Escolhe o último elemento como pivô
        int i = inicio - 1;    // Índice do menor elemento

        for (int j = inicio; j < fim; j++) {
            // Se o elemento atual for menor ou igual ao pivô
            if (array[j] <= pivo) {
                i++;
                // Troca array[i] e array[j]
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }

        // Coloca o pivô na sua posição definitiva (logo após os menores)
        int temp = array[i + 1];
        array[i + 1] = array[fim];
        array[fim] = temp;

        return i + 1; // Retorna a posição final do pivô
    }

}
    


