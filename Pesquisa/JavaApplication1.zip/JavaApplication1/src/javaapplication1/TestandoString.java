/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author laboratorio
 */
public class TestandoString {
    public static void main(String[] args) {
        String sFrase = "alexadnre de oliveira zamberlan e alexadnre de oliveira silva";
        StringBuffer sbFrase = new StringBuffer("alexadnre de oliveira zamberlan e alexadnre de oliveira silva");
        StringBuilder sbuilderFrase = new StringBuilder("alexadnre de oliveira zamberlan e alexadnre de oliveira silva");
        
    }
}